To run:
python3 main.py

runs best when terminal is in fullscreen mode

All powerups except ball multiplier have been implemented
P - paddle grab
T - thru ball
s - shrink paddle
E - expand paddle
F - fast ball

RULES:

Total Lives = 5

You loose a life if the ball falls down

Blocks are colour coded on the basis of their strength, white being unbreakable, blue with 3 strength, orange with 2 strength and green with 1 strength

Each powerup lasts 15 seconds

Each hit gives 1 point(not if hit is to unbreakable block) and additional point is given when a brick is broken(except in the case of green brick)

There is no time limit


GUIDE:

Use 'a' and 'd' keys to move the paddle, the ball velocity increases based on the paddles velocity and point of impact during the collsion

When the paddle grab powerup is obtained press 'p' to release the ball
